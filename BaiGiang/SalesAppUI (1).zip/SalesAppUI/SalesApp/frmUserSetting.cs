﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SalesApp
{
    public partial class frmUserSetting : Form
    {
        public static string connStr = @"Data Source=DESKTOP-L05RC32\SQLEXPRESS;Initial Catalog=BanHang;Integrated Security=True";
        SqlConnection conn = null;


        public frmUserSetting()
        {
            InitializeComponent();
        }

        private void frmUserSetting_Load(object sender, EventArgs e)
        {
            cboExecute.Text = "/";

            //begin: list users
            conn = new SqlConnection(connStr);
            conn.Open();    
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            cmd.CommandText = "select * from MTUsers";
            SqlDataReader Reader = cmd.ExecuteReader();
            string userlist = "";
            while (Reader.Read())
            {
                userlist = userlist + Reader[0].ToString() + "\r\n";
                txtUserList.Text = userlist;
            }
            Reader.Close();
            //end: list users
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            frmLogin frmlogin = new frmLogin();
            frmlogin.Show();
            this.Hide();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(connStr);
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;

            //begin: Search
            cmd.CommandText = @"select Fullname from MTUsers where Username like '%' + @Username + '%'";
            cmd.CommandType = CommandType.Text;

            cmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = txtSearch.Text.Trim();

            object kq = cmd.ExecuteScalar();
            if (kq == null)
            {
                MessageBox.Show("Khong tim thay!");
            }
            else
            {
                txtUserList.Text = kq.ToString();
            }
            //end: Search
        }

        private void cboExecute_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboExecute.Text == "Add New")
            {
                txtUsername.Enabled = true;
                txtSearch.Enabled = false;
                btnSave.Enabled = true;
                btnSearch.Enabled = false;
                btnDelete.Enabled = false;
            }
            else if (cboExecute.Text == "Update")
            {
                txtSearch.Enabled = true;
                txtUsername.Enabled = false;
                btnSave.Enabled = true;
                btnSearch.Enabled = true;
                btnDelete.Enabled = false;
            }
            else if (cboExecute.Text == "Delete")
            {
                txtUsername.Enabled = false;
                btnSave.Enabled = false;
                btnSearch.Enabled = true;
                btnDelete.Enabled = true;
            }
            else
            {
                txtUsername.Enabled = false;
                btnSave.Enabled = false;
                btnSearch.Enabled = true;
                btnDelete.Enabled = false;
            }
            txtSearch.Text = "";
            txtFullname.Text = "";
            txtPassword.Text = "";
            txtUsername.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (cboExecute.Text == "Add New")
            {
                try
                {
                    if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text) ||
                         string.IsNullOrEmpty(txtFullname.Text) || string.IsNullOrEmpty(cboRole.Text))
                    {
                        MessageBox.Show("Nhập đầy đủ thông tin!");
                    }
                    else
                    {
                        //begin: connect database - Thao tac xu ly du lieu
                        conn = new SqlConnection(connStr);
                        conn.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = conn;

                        //begin: add
                        cmd.CommandText = @"insert into MTUsers(Username, Password, Fullname, Role) 
                                               values(@Username, @Password, @Fullname, @Role)";
                        cmd.CommandType = CommandType.Text;

                        cmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = txtUsername.Text.Trim();
                        cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = txtPassword.Text.Trim();
                        cmd.Parameters.Add("@Fullname", SqlDbType.NVarChar).Value = txtFullname.Text.Trim();
                        cmd.Parameters.Add("@Role", SqlDbType.NVarChar).Value = cboRole.Text.ToString();

                        int kq = cmd.ExecuteNonQuery();
                        //end: add
                        
                        ////begin: list users 
                        //conn.Open();
                        //cmd.Connection = conn;
                        //cmd.CommandText = "select * from MTUsers";
                        //SqlDataReader Reader = cmd.ExecuteReader();
                        //string userlist = "";
                        //while (Reader.Read())
                        //{
                        //    userlist = userlist + Reader[0].ToString() + "\r\n";
                        //    txtUserList.Text = userlist;
                        //}
                        //Reader.Close();
                        ////end: list users

                        MessageBox.Show("Them thanh cong!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            if (cboExecute.Text == "Update")
            {
                conn = new SqlConnection(connStr);
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;

                //begin: Search
                cmd.CommandText = @"select Fullname from MTUsers where Username like '%' + @Username + '%'";
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = txtSearch.Text.Trim();

                object kq = cmd.ExecuteScalar();
                if (kq == null)
                {
                    MessageBox.Show("Khong tim thay!");
                }
                else
                {
                    txtUserList.Text = kq.ToString();
                }
                //end: Search

                //begin: update
                cmd.CommandText = @"UPDATE MTUsers SET Password, Fullname, Role)  values(@Password, @Fullname, @Role)";
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = txtPassword.Text.Trim();
                cmd.Parameters.Add("@Fullname", SqlDbType.NVarChar).Value = txtFullname.Text.Trim();
                cmd.Parameters.Add("@Role", SqlDbType.NVarChar).Value = cboRole.Text.ToString();
                //end: update
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                //Mo ket noi CSDL: su dung SqlConnection
                conn = new SqlConnection(connStr);
                conn.Open();
                //Thao tac xu ly du lieu: SU dung SqlCommand
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn; //Nam giu ket noi

                cmd.CommandText = @"delete from MTUsers  where Username like @Username"; //Nam giu  cua T-SQL
                cmd.CommandType = CommandType.Text; //Nam giu kieu cua CommandText

                //parameter
                cmd.Parameters.Add("@username", SqlDbType.NVarChar).Value = txtSearch.Text.Trim();

                int KQ = cmd.ExecuteNonQuery();        //lay value dau tien xuat hien tu cau truy van
                if (KQ == 0)
                {
                    MessageBox.Show("Xoa khong thanh cong");
                }
                else
                {
                    MessageBox.Show("Xoa thanh cong");
                }
                //MessageBox.Show(KQ.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtUserList_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
