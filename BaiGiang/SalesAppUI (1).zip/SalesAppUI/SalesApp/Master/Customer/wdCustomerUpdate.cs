﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesApp.Master.Customer
{
    public partial class wdCustomerUpdate : Form
    {
        public wdCustomerUpdate()
        {
            InitializeComponent();
        }

        public wdCustomerUpdate(bool isAddNew)
        {
            InitializeComponent();
            if(isAddNew==true)
            {
                lblTitle.Text = "CUSTOMER - ADD NEW";
            }
            else
            {
                lblTitle.Text = "CUSTOMER - UPDATE";
            }
        }

    }
}
