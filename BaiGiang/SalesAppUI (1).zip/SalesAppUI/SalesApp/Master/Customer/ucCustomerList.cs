﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesApp.Master.Customer
{
    public partial class ucCustomerList : UserControl
    {
        public ucCustomerList()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            BaseClass.LoadUC((Panel)Parent, new ucMenu());
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            bool isAddNew = true;
            wdCustomerUpdate frmCustomerNew = new wdCustomerUpdate(isAddNew);
            frmCustomerNew.StartPosition = FormStartPosition.CenterScreen;
            frmCustomerNew.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            bool isAddNew = false;
            wdCustomerUpdate frmCustomerNew = new wdCustomerUpdate(isAddNew);
            frmCustomerNew.StartPosition = FormStartPosition.CenterScreen;
            frmCustomerNew.ShowDialog();
        }
    }
}
