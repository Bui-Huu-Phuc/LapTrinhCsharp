﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesApp.Master.Product
{
    public partial class ucProductList : UserControl
    {
        public ucProductList()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            BaseClass.LoadUC((Panel)Parent, new ucMenu());
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            wdProductUpdate frmProduct = new wdProductUpdate(true);
            frmProduct.StartPosition = FormStartPosition.CenterScreen;
            frmProduct.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            wdProductUpdate frmProduct = new wdProductUpdate(false);
            frmProduct.StartPosition = FormStartPosition.CenterScreen;
            frmProduct.ShowDialog();
        }
    }
}
