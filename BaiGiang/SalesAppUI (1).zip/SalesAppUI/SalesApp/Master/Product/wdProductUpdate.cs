﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesApp.Master.Product
{
    public partial class wdProductUpdate : Form
    {
        public wdProductUpdate()
        {
            InitializeComponent();
        }

        public wdProductUpdate(bool isAddNew)
        {
            InitializeComponent();
            if(isAddNew==true)
            {
                lblTitle.Text = "PRODUCT - ADD NEW";
            }
            else
            {
                lblTitle.Text = "PRODUCT - UPDATE";
            }
        }
    }
}
