﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesApp.Master.Employee
{
    public partial class wdEmployeeUpdate : Form
    {
        public wdEmployeeUpdate()
        {
            InitializeComponent();
        }

        public wdEmployeeUpdate(bool isAddNew)
        {
            InitializeComponent();
            if(isAddNew==true)
            {
                lblTitle.Text = "EMPLOYEE - ADD NEW";
            }
            else
            {
                lblTitle.Text = "EMPLOYEE - UPDATE";
            }
        }

    }
}
