﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesApp.Master.Deliver
{
    public partial class wdDeliverUpdate : Form
    {
        public wdDeliverUpdate()
        {
            InitializeComponent();
        }

        public wdDeliverUpdate(bool isAddNew)
        {
            InitializeComponent();
            if(isAddNew==true)
            {
                lblTitle.Text = "DELIVERY - ADD NEW";
            }
            else
            {
                lblTitle.Text = "DELIVERY - UPDATE";
            }
        }
    }
}
