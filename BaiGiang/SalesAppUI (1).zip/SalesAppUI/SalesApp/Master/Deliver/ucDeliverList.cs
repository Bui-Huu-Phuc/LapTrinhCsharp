﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesApp.Master.Deliver
{
    public partial class ucDeliverList : UserControl
    {
        public ucDeliverList()
        {
            InitializeComponent();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            BaseClass.LoadUC((Panel)Parent, new ucMenu());
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            wdDeliverUpdate frmDelivery = new wdDeliverUpdate(true);
            frmDelivery.StartPosition = FormStartPosition.CenterScreen;
            frmDelivery.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            wdDeliverUpdate frmDelivery = new wdDeliverUpdate(false);
            frmDelivery.StartPosition = FormStartPosition.CenterScreen;
            frmDelivery.ShowDialog();
        }
    }
}
