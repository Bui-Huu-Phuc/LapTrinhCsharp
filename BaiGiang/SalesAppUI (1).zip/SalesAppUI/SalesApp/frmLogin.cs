﻿using SalesApps;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace SalesApp
{
    public partial class frmLogin : Form
    {
        public static string connStr = @"Data Source=DESKTOP-L05RC32\SQLEXPRESS;Initial Catalog=BanHang;Integrated Security=True";
        SqlConnection conn = null;


        public frmLogin()
        {
            InitializeComponent();
            txtUsername.GotFocus += TxtUsername_GotFocus;
            txtPassword.GotFocus += TxtPassword_GotFocus;
        }

        private void TxtPassword_GotFocus(object sender, EventArgs e)
        {
            txtPassword.SelectAll();
        }

        private void TxtUsername_GotFocus(object sender, EventArgs e)
        {
            txtUsername.SelectAll();
        }


        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUsername.Text) || string.IsNullOrEmpty(txtPassword.Text))
            {
                MessageBox.Show("Nhập đầy đủ thông tin!");
            }
            else
            {
                
                conn = new SqlConnection(connStr);
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandText = @"select * from MTUsers where Username = @Username and Password = @Password";
                cmd.CommandType = CommandType.Text;

                cmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = txtUsername.Text.Trim();
                cmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = txtPassword.Text.Trim();

                object loginOK = cmd.ExecuteScalar();
                if (loginOK == null)
                {
                    MessageBox.Show("Login không thành công!");
                }
                else
                {
                    frmMainForm frmMain = new frmMainForm();
                    frmMain.Show();
                    this.Hide();
                }

                
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //this.Close();
            System.Windows.Forms.Application.Exit(); //thoát h?n chuong trình
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmUserSetting frmuser = new frmUserSetting();
            frmuser.Show();
            this.Hide();
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
           
        }
    }
}
