﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace SalesApp
{
    public static class BaseClass
    {
        public static void LoadUC(Panel nen, UserControl UControl)
        {
            nen.Controls.Clear();
            UControl.Top = (nen.Height - UControl.Height) / 2;
            UControl.Left = (nen.Width - UControl.Width) / 2;
            nen.Controls.Add(UControl);
            UControl.Dock = DockStyle.Fill;
        }
    }
}
